from gemini_client import generate_with_gemini

def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a structured learning path for the topic below.

Topic: {topic}

Organize it from beginner to advanced level.
For each stage provide:
1. Concepts to learn
2. Suggested sequence
3. Approximate timeline
4. Useful learning resources such as videos, articles, or books

Keep the guidance practical and easy to follow.
"""
    return generate_with_gemini(prompt)

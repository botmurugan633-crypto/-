# EduGenie: Google Gemini Powered Learning Assistant

EduGenie is a lightweight AI-powered educational assistant based on the supplied project document.

## Features

- Question answering
- Simplified concept explanation
- Quiz generation
- Text summarization
- Personalized learning recommendations

## Technology

- Python 3.10+
- FastAPI
- HTML/CSS
- Google Gemini API
- LaMini-Flan-T5-783M
- Uvicorn
- Jinja2

## Project Structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── templates/
│   └── index.html
├── static/
│   └── style.css
├── requirements.txt
├── .env.example
└── README.md
```

## Installation

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create a virtual environment:

```bash
python -m venv venv
```

4. Activate it.

Windows:
```bash
venv\Scripts\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

5. Install dependencies:

```bash
pip install -r requirements.txt
```

6. Copy `.env.example` to `.env`.
7. Add your Google Gemini API key to `.env`.

Example:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-1.5-pro
```

## Run

```bash
uvicorn main:app --reload
```

Open:

http://127.0.0.1:8000

## API Endpoints

- POST `/qa`
- POST `/explain`
- POST `/quiz`
- POST `/summarize`
- POST `/learn/recommendations`

The `/ask` route is used by the web interface.

## Important

Never upload or commit your real `.env` file or API key to a public repository.

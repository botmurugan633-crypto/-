import json
import re
from gemini_client import generate_with_gemini

def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()

def generate_quiz(passage: str):
    prompt = f"""
Create exactly 3 multiple-choice questions from the passage below.

Return ONLY valid JSON in this format:
[
  {{
    "question": "Question text",
    "options": ["A", "B", "C", "D"],
    "correct_answer": "A"
  }}
]

Make the questions relevant to the passage and make the incorrect
options plausible.

Passage:
{passage}
"""

    raw = generate_with_gemini(prompt)
    cleaned = clean_json_block(raw)

    try:
        quiz = json.loads(cleaned)

        if not isinstance(quiz, list) or len(quiz) != 3:
            raise ValueError("Quiz must contain exactly 3 questions.")

        for item in quiz:
            if not all(k in item for k in ("question", "options", "correct_answer")):
                raise ValueError("Invalid quiz item structure.")
            if len(item["options"]) != 4:
                raise ValueError("Each question must have 4 options.")

        return quiz

    except Exception as exc:
        return {"error": f"Quiz generation/parsing failed: {exc}", "raw_response": raw}

def explain_topic(topic: str) -> str:
    """
    Lightweight concept explanation module.
    The project document specifies LaMini-Flan-T5-783M
    for local concept explanation. If the local model
    is installed, this function uses it; otherwise it
    returns a setup message.
    """
    try:
        from transformers import pipeline

        generator = pipeline(
            "text2text-generation",
            model="MBZUAI/LaMini-Flan-T5-783M"
        )

        prompt = (
            "Explain the following topic in simple language for a student. "
            "Give a clear definition, key points, and a small example: "
            f"{topic}"
        )

        result = generator(prompt, max_new_tokens=220, do_sample=False)
        return result[0]["generated_text"]

    except ImportError:
        return (
            "Local explanation model is not installed. "
            "Install the dependencies from requirements.txt "
            "to enable LaMini-Flan-T5 concept explanation."
        )
    except Exception as exc:
        return f"Explanation module error: {exc}"

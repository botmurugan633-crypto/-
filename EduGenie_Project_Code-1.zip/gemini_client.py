import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

if API_KEY:
    genai.configure(api_key=API_KEY)

def generate_with_gemini(prompt: str) -> str:
    if not API_KEY:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured. Add it to the .env file."
        )

    model = genai.GenerativeModel(MODEL_NAME)
    response = model.generate_content(prompt)

    if not response or not getattr(response, "text", None):
        raise RuntimeError("Gemini returned an empty response.")

    return response.text.strip()

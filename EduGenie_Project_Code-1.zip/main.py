import os
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from explanation_module import explain_topic
from qna import answer_question
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations

load_dotenv()

app = FastAPI(title="EduGenie - Google Gemini Powered Learning Assistant")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "result": None})

@app.post("/qa")
async def qa(question: str = Form(...)):
    return {"answer": answer_question(question)}

@app.post("/explain")
async def explain(topic: str = Form(...)):
    return {"explanation": explain_topic(topic)}

@app.post("/quiz")
async def quiz(text: str = Form(...)):
    return {"quiz": generate_quiz(text)}

@app.post("/summarize")
async def summarize(text: str = Form(...)):
    return {"summary": summarize_text(text)}

@app.post("/learn/recommendations")
async def recommendations(topic: str = Form(...)):
    return {"recommendations": get_learning_recommendations(topic)}

@app.post("/ask", response_class=HTMLResponse)
async def ask_web(
    request: Request,
    task: str = Form(...),
    text: str = Form(...)
):
    try:
        if task == "qa":
            result = answer_question(text)
        elif task == "explain":
            result = explain_topic(text)
        elif task == "quiz":
            result = generate_quiz(text)
        elif task == "summary":
            result = summarize_text(text)
        elif task == "learn":
            result = get_learning_recommendations(text)
        else:
            result = "Invalid task selected."
    except Exception as exc:
        result = f"Error: {exc}"

    return templates.TemplateResponse(
        "index.html",
        {"request": request, "result": result, "selected_task": task, "input_text": text}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)

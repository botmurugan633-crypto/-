from gemini_client import generate_with_gemini

def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational passage.
Keep the main information, remove unnecessary repetition,
and make the result easy for a student to revise.

Passage:
{text}
"""
    return generate_with_gemini(prompt)

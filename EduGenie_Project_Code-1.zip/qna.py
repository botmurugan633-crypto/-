from gemini_client import generate_with_gemini

def answer_question(question: str) -> str:
    prompt = f"""
You are EduGenie, an educational assistant.
Answer the following academic question clearly and concisely.
Use simple language and include important points.

Question:
{question}
"""
    return generate_with_gemini(prompt)
